GTA VI COUNTDOWN - ANDROID STUDIO PROJEKT

Dieses Projekt baut eine native Android-App-Huelle (WebView) fuer den Countdown.

APK erstellen:
1. Android Studio installieren und starten.
2. In Android Studio: Open waehlen und diesen entpackten Projektordner oeffnen.
3. Warten, bis Gradle-Synchronisierung abgeschlossen ist. Falls Android SDK 35 fehlt,
   die angebotene Installation bestaetigen.
4. Menue Build > Build Bundle(s) / APK(s) > Build APK(s) waehlen.
5. Die APK liegt anschliessend unter app/build/outputs/apk/debug/app-debug.apk.
6. APK aufs Android-Handy uebertragen und antippen, um sie zu installieren.

Hinweis: Das hier ist der Projekt-Quellcode, keine bereits kompilierte APK.
